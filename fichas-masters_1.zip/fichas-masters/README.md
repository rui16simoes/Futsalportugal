# Fichas de jogo — Record International Masters Futsal 2026

Fichas dos quatro jogos do torneio (Portimão Arena, 29 e 30 de Agosto de 2026),
preenchíveis no browser. Página única, sem dependências: o logo e os planteis
estão embutidos no próprio `index.html`.

## Pôr online no GitHub Pages

1. Cria um repositório novo (público).
2. Envia o conteúdo desta pasta para a raiz do repositório — `index.html` e `.nojekyll`.
3. No repositório, vai a **Settings → Pages**.
4. Em **Build and deployment → Source**, escolhe **Deploy from a branch**.
5. Escolhe a branch `main` e a pasta `/ (root)`. Guarda.
6. Ao fim de um minuto fica em `https://UTILIZADOR.github.io/REPOSITORIO/`.

O ficheiro `.nojekyll` só serve para o GitHub servir a página tal como está,
sem a processar.

## Embeber numa notícia

```html
<div style="position:relative;width:100%;padding-top:145%;border-radius:6px;overflow:hidden;background:#0A1440">
  <iframe
    src="https://UTILIZADOR.github.io/REPOSITORIO/"
    title="Ficha de jogo — Record International Masters Futsal 2026"
    loading="lazy"
    style="position:absolute;inset:0;width:100%;height:100%;border:0"></iframe>
</div>
```

O `padding-top` define a altura: 120% mais baixa, 170% mais alta.

## Como funciona o preenchimento

- Separadores no topo para escolher o jogo.
- **P / S / N** — clica na célula para marcar o X, clica outra vez para tirar.
  P equipa principal, S substituto, N não convocado.
- Números e nomes são editáveis, para corrigir à última hora.
- **Guardar** grava no navegador de quem está a preencher (fica nesse
  dispositivo). Não altera o que os outros vêem.
- **Descarregar HTML** gera um `index.html` novo já com tudo preenchido.
  É esse ficheiro que substituis no repositório para actualizar a página pública.

## Actualizar durante o torneio

Preenche → **Descarregar HTML** → substitui o `index.html` no repositório.
O GitHub Pages reconstrói sozinho em cerca de um minuto.
